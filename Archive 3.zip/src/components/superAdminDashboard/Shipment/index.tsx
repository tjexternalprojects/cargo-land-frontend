
const Shipment = () => {

	return (
		<div></div>
	);
};

export default Shipment;
