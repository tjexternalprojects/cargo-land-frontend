function useDashboard() {

	return {};
}

export default useDashboard;
