
function useTransitions () {
    return {}
}
export default useTransitions