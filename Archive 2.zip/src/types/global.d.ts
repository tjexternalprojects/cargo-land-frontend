declare global {
	interface Window {
		gapi: any;
	}
}
