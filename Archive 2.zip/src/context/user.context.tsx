
function UserContext(){
    const single_user_data = null
    return{single_user_data}
}
export default UserContext