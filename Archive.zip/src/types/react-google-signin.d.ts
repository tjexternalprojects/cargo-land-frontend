declare module 'react-google-signin';
