declare module 'google-maps' {
	export = google;
}
