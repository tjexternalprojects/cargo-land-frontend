import { LocalStorageServices } from "@/services";
import { useState } from "react";

function usePersonalDetails(){

    return{ }
}
export default usePersonalDetails