function usePersonalDetails(){
    return{}
}
export default usePersonalDetails