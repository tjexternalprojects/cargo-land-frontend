function useAccountType(){
    return{}
}
export default useAccountType;