function usePayment() {
	const handlePayment = () => {};
	return {
		handlePayment,
	};
}
export default usePayment;
