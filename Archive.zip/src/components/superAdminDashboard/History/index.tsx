import React from 'react';

const History = () => {
	return (
		<div>
			Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aliquam, velit enim deleniti optio
			vel deserunt, ipsa ab necessitatibus harum impedit placeat provident maxime reprehenderit
			quam. Ipsam sit maxime laboriosam temporibus.
		</div>
	);
};

export default History;
