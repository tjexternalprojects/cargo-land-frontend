function useUsers () {
    const users = [
        {
            'uid':'xxx2222',
            'full_name':'David Adegbetan',
            'email':'da@gmail.com',
            'phone_number':'08144324546',
            'account_type':'Regular',
            'account_status':'Active'
        }
    ]
    return {users}
}
export default useUsers