import React from 'react'

const UserDetailsModal = () => {
  return (
    <div>
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Corrupti ad iure quaerat sit pariatur quisquam asperiores blanditiis autem exercitationem mollitia quod libero, accusamus id ducimus laborum ex ut nulla incidunt?
    </div>
  )
}

export default UserDetailsModal
