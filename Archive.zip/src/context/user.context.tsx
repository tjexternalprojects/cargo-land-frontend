
function UserContext(){
    const single_user_data = null
    const userCurrentTab = 'item1';
    return{single_user_data, userCurrentTab}
}
export default UserContext