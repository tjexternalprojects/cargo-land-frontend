
function UserContext(){
    const user_data = null
    return{user_data}
}
export default UserContext